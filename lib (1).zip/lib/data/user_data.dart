import 'package:instructor/models/user_data.dart';

late UserData myUserData;
